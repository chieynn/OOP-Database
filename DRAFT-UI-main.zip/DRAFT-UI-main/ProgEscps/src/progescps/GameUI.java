package progescps;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.io.PrintStream;

/**
 * Simple tablet-like UI where the right green area is the console (raw System.out output).
 * Left column: character placeholder (yellow), dynamic stats (red), control buttons (orange).
 * Right column: green console area. The blue input field is now placed under the green console area
 * only (i.e. inside the right panel) and does NOT extend under the left column.
 *
 * The UI forwards input lines to the game's InputProvider so GameManager reads them unchanged.
 */
public class GameUI {

    private final JFrame frame;
    private final InputProvider inputProvider;
    private final GameManager manager;

    // Left column components
    private final JLabel gifPlaceholder;
    private final JLabel classLabel;
    private final JLabel hpLabel;
    private final JLabel manaLabel;
    private final JLabel goldLabel;

    // Right column: console
    private final JTextArea consoleArea;

    // Bottom input (now inside the right panel)
    private final JTextField inputField;

    public GameUI() {
        // disable ANSI coloring so console text looks plain inside Swing components
        try { progescps.Color.USE_ANSI = false; } catch (Throwable ignored) {}

        this.inputProvider = new InputProvider();
        this.manager = new GameManager(inputProvider);

        frame = new JFrame("Codeborne - UI Console");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(820, 520);
        frame.setResizable(false);
        frame.setLayout(new BorderLayout(6, 6));

        // Split left / right
        JSplitPane split = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT);
        split.setDividerLocation(260);
        split.setResizeWeight(0.0);
        split.setBorder(null);

        // LEFT panel
        JPanel left = new JPanel(new BorderLayout(8, 8));
        left.setBorder(new EmptyBorder(8, 8, 8, 8));

        // Yellow placeholder for character gif
        gifPlaceholder = new JLabel("CHARACTER GIF", SwingConstants.CENTER);
        gifPlaceholder.setOpaque(true);
        gifPlaceholder.setBackground(java.awt.Color.YELLOW);
        gifPlaceholder.setPreferredSize(new Dimension(240, 240));
        gifPlaceholder.setBorder(BorderFactory.createLineBorder(java.awt.Color.DARK_GRAY));
        left.add(gifPlaceholder, BorderLayout.NORTH);

        // Red stats area
        JPanel stats = new JPanel(new GridLayout(4, 1, 4, 4));
        stats.setBackground(new java.awt.Color(200, 255, 200));
        stats.setBorder(BorderFactory.createLineBorder(java.awt.Color.DARK_GRAY));
        classLabel = new JLabel("Class: -");
        classLabel.setForeground(java.awt.Color.BLACK);
        hpLabel = new JLabel(" HP: - / -");
        hpLabel.setForeground(java.awt.Color.BLACK);
        manaLabel = new JLabel(" Mana: - / -");
        manaLabel.setForeground(java.awt.Color.BLACK);
        goldLabel = new JLabel(" Gold: -");
        goldLabel.setForeground(java.awt.Color.BLACK);
        stats.add(classLabel);
        stats.add(hpLabel);
        stats.add(manaLabel);
        stats.add(goldLabel);
        left.add(stats, BorderLayout.CENTER);

        // Orange control buttons
        JPanel controls = new JPanel(new GridLayout(2, 2, 8, 8));
        controls.setBackground(java.awt.Color.WHITE);
        JButton newBtn = new JButton("New Game");
        JButton saveBtn = new JButton("Save Game");
        JButton loadBtn = new JButton("Load Game");
        JButton quitBtn = new JButton("Quit Game");
        controls.add(newBtn);
        controls.add(saveBtn);
        controls.add(loadBtn);
        controls.add(quitBtn);
        left.add(controls, BorderLayout.SOUTH);

        // Button actions: send likely menu commands or call manager wrappers if present
        newBtn.addActionListener(e -> {
            try { manager.uiNewGame(); } catch (Throwable ex) { inputProvider.submitTrimmed("1"); }
        });
        saveBtn.addActionListener(e -> {
            try { manager.uiSaveGame(); } catch (Throwable ex) { inputProvider.submitTrimmed("8"); }
        });
        loadBtn.addActionListener(e -> {
            try { manager.uiLoadGame(); } catch (Throwable ex) { inputProvider.submitTrimmed("2"); }
        });
        quitBtn.addActionListener(e -> {
            try { manager.uiQuitGame(); } catch (Throwable ex) {
                inputProvider.submitTrimmed("3");
                int r = JOptionPane.showConfirmDialog(frame, "Exit the game?", "Quit", JOptionPane.YES_NO_OPTION);
                if (r == JOptionPane.YES_OPTION) System.exit(0);
            }
        });

        // RIGHT panel: console area (green)
        JPanel right = new JPanel(new BorderLayout(8, 8));
        right.setBorder(new EmptyBorder(8, 8, 8, 8));
        consoleArea = new JTextArea();
        consoleArea.setEditable(false);
        consoleArea.setLineWrap(true);
        consoleArea.setWrapStyleWord(true);
        consoleArea.setFont(new Font(Font.MONOSPACED, Font.PLAIN, 12));
        consoleArea.setBackground(new java.awt.Color(200, 255, 200)); // light green
        consoleArea.setMargin(new Insets(8, 8, 8, 8));
        JScrollPane consoleScroll = new JScrollPane(consoleArea,
                JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED, JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        right.add(consoleScroll, BorderLayout.CENTER);

        // Bottom of RIGHT panel: blue input field (only under the green console)
        JPanel inputPanel = new JPanel(new BorderLayout());
        inputField = new JTextField();
        inputField.setBackground(java.awt.Color.WHITE);
        inputField.setForeground(java.awt.Color.BLACK);
        inputField.setPreferredSize(new Dimension(520, 36));
        inputPanel.add(inputField, BorderLayout.CENTER);
        // Optional "Send" button on the right of the input field
        JButton sendBtn = new JButton("Send");
        inputPanel.add(sendBtn, BorderLayout.EAST);
        right.add(inputPanel, BorderLayout.SOUTH);

        // Submit on Enter or Send button
        inputField.addActionListener(e -> submitFromInputField());
        sendBtn.addActionListener(e -> submitFromInputField());

        split.setLeftComponent(left);
        split.setRightComponent(right);
        frame.add(split, BorderLayout.CENTER);

        // Setup interceptor and redirect System.out/System.err to consoleArea
        ConsoleOutputInterceptor interceptor = new ConsoleOutputInterceptor(consoleArea);
        PrintStream ps = new PrintStream(interceptor, true);
        System.setOut(ps);
        System.setErr(ps);

        // Show frame
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);

        // Start the GameManager in a background thread
        Thread gameThread = new Thread(() -> {
            try {
                manager.start();
            } catch (Throwable t) {
                t.printStackTrace();
            }
        }, "Game-Thread");
        gameThread.setDaemon(true);
        gameThread.start();

        // Periodic refresh of stats
        javax.swing.Timer statsTimer = new javax.swing.Timer(500, evt -> refreshStats());
        statsTimer.setRepeats(true);
        statsTimer.start();
        frame.addWindowListener(new java.awt.event.WindowAdapter() {
            @Override
            public void windowClosing(java.awt.event.WindowEvent e) {
                statsTimer.stop();
            }
        });
    }

    private void submitFromInputField() {
        String text = inputField.getText();
        if (text == null) text = "";
        inputField.setText("");
        // echo into console area so user sees entered text
        consoleArea.append("> " + text + System.lineSeparator());
        consoleArea.setCaretPosition(consoleArea.getDocument().getLength());
        inputProvider.submitTrimmed(text);
    }

    private void refreshStats() {
        try {
            Hero p = manager.player;
            if (p == null) {
                SwingUtilities.invokeLater(() -> {
                    classLabel.setText("Class: -");
                    hpLabel.setText("HP: - / -");
                    manaLabel.setText("Mana: - / -");
                    goldLabel.setText("Gold: -");
                });
                return;
            }
            final String cls = p.getClassName();
            final String hp = "HP: " + p.hp + " / " + p.maxHP;
            final String mana = "Mana: " + p.mana + " / " + p.maxMana;
            final String gold = "Gold: " + p.getGold();
            SwingUtilities.invokeLater(() -> {
                classLabel.setText("Class: " + cls);
                hpLabel.setText(hp);
                manaLabel.setText(mana);
                goldLabel.setText(gold);
            });
        } catch (Throwable ignored) {}
    }

    public static void launch() {
        SwingUtilities.invokeLater(GameUI::new);
    }
}